﻿namespace es56b;
using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        // Lista dei cibi con prezzi
        Dictionary<int, Cibo> cibi = new Dictionary<int, Cibo>()
        {
            { 1, new Cibo("Coca Cola 150 ml", 2.50) },
            { 2, new Cibo("Insalata di pollo", 5.20) },
            { 3, new Cibo("Pizza Margherita", 10.00) },
            { 4, new Cibo("Pizza 4 Formaggi", 12.50) },
            { 5, new Cibo("Pz patatine fritte", 3.50) },
            { 6, new Cibo("Insalata di riso", 8.00) },
            { 7, new Cibo("Frutta di stagione", 5.00) },
            { 8, new Cibo("Pizza fritta", 5.00) },
            { 9, new Cibo("Piadina vegetariana", 6.00) },
            { 10, new Cibo("Panino Hamburger", 7.90) }
        };

        // Lista delle scelte dell'utente
        List<Cibo> scelte = new List<Cibo>();

        // Ciclo per la selezione dei cibi
        bool continuare = true;
        while (continuare)
        {
            MostraMenu(cibi);
            int scelta = GetNumeroScelta();

            if (scelta == 11)
            {
                // Stampa conto
                StampaConto(scelte);
                continuare = false;
            }
            else if (scelta > 0 && scelta <= cibi.Count)
            {
                // Aggiungi cibo alla lista
                scelte.Add(cibi[scelta]);
            }
            else
            {
                Console.WriteLine("Scelta non valida. Riprova.");
            }
        }
    }

    static void MostraMenu(Dictionary<int, Cibo> cibi)
    {
        Console.WriteLine("==============MENU==============");
        foreach (var cibo in cibi)
        {
            Console.WriteLine("{0}: {1} (€ {2})", cibo.Key, cibo.Value.Nome, cibo.Value.Prezzo);
        }
        Console.WriteLine("11: Stampa conto finale e conferma");
        Console.WriteLine("==============MENU==============");
    }

    static int GetNumeroScelta()
    {
        int scelta;
        while (!int.TryParse(Console.ReadLine(), out scelta))
        {
            Console.WriteLine("Inserisci un numero valido: ");
        }
        return scelta;
    }

    static void StampaConto(List<Cibo> scelte)
    {
        Console.WriteLine("\n==============CONTO==============");
        foreach (var cibo in scelte)
        {
            Console.WriteLine("{0}: € {1}", cibo.Nome, cibo.Prezzo);
        }
        double totale = CalcolaTotale(scelte);
        Console.WriteLine("Servizio al tavolo: € 3.00");
        Console.WriteLine("Totale: € {0}", totale + 3.00);
        Console.WriteLine("==============CONTO==============");
    }

    static double CalcolaTotale(List<Cibo> scelte)
    {
        double totale = 0;
        foreach (var cibo in scelte)
        {
            totale += cibo.Prezzo;
        }
        return totale;
    }
}

class Cibo
{
    public string Nome { get; set; }
    public double Prezzo { get; set; }

    public Cibo(string nome, double prezzo)
    {
        Nome = nome;
        Prezzo = prezzo;
    }
}

